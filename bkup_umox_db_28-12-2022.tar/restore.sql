--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE umox_db;
--
-- Name: umox_db; Type: DATABASE; Schema: -; Owner: pgadmin
--

CREATE DATABASE umox_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE umox_db OWNER TO pgadmin;

\connect umox_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: itens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.itens (
    id_item integer NOT NULL,
    descricao_item character varying(150) NOT NULL,
    id_natureza integer NOT NULL,
    marca_item character varying(40) NOT NULL,
    un_medida_item character varying(20) NOT NULL,
    estoque_item integer NOT NULL
);


ALTER TABLE public.itens OWNER TO postgres;

--
-- Name: itens_pedido; Type: TABLE; Schema: public; Owner: pgadmin
--

CREATE TABLE public.itens_pedido (
    id_item integer NOT NULL,
    id_pedido integer NOT NULL,
    qtd_solicitada numeric(6,2) NOT NULL,
    qtd_atendida numeric(6,2)
);


ALTER TABLE public.itens_pedido OWNER TO pgadmin;

--
-- Name: meses_para_relatorio; Type: TABLE; Schema: public; Owner: pgadmin
--

CREATE TABLE public.meses_para_relatorio (
    id integer NOT NULL,
    mes character varying(15) NOT NULL,
    ref character varying NOT NULL
);


ALTER TABLE public.meses_para_relatorio OWNER TO pgadmin;

--
-- Name: naturezas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.naturezas (
    id_natureza integer NOT NULL,
    natureza character varying(250) NOT NULL
);


ALTER TABLE public.naturezas OWNER TO postgres;

--
-- Name: pedidos; Type: TABLE; Schema: public; Owner: pgadmin
--

CREATE TABLE public.pedidos (
    id_pedido integer NOT NULL,
    id_usuario uuid NOT NULL,
    data_pedido date NOT NULL,
    data_atendimento date,
    finalidade_pedido text,
    status_pedido character varying(30) DEFAULT 'AGUARDANDO ATENDIMENTO'::character varying,
    observacao_atendimento text
);


ALTER TABLE public.pedidos OWNER TO pgadmin;

--
-- Name: pedidos_id_pedido_seq; Type: SEQUENCE; Schema: public; Owner: pgadmin
--

CREATE SEQUENCE public.pedidos_id_pedido_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedidos_id_pedido_seq OWNER TO pgadmin;

--
-- Name: pedidos_id_pedido_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgadmin
--

ALTER SEQUENCE public.pedidos_id_pedido_seq OWNED BY public.pedidos.id_pedido;


--
-- Name: perfis; Type: TABLE; Schema: public; Owner: pgadmin
--

CREATE TABLE public.perfis (
    perfil character varying(30) NOT NULL,
    permissoes json NOT NULL
);


ALTER TABLE public.perfis OWNER TO pgadmin;

--
-- Name: ref_mes_atual; Type: VIEW; Schema: public; Owner: pgadmin
--

CREATE VIEW public.ref_mes_atual AS
 SELECT min(meses_para_relatorio.id) AS id_mes_atual
   FROM public.meses_para_relatorio
  WHERE ((meses_para_relatorio.ref)::text = (date_part('month'::text, CURRENT_DATE))::text);


ALTER TABLE public.ref_mes_atual OWNER TO pgadmin;

--
-- Name: ref_ult_12meses; Type: VIEW; Schema: public; Owner: pgadmin
--

CREATE VIEW public.ref_ult_12meses AS
 SELECT meses_para_relatorio.id,
    concat(meses_para_relatorio.ref, '/',
        CASE
            WHEN (meses_para_relatorio.id <= 12) THEN date_part('year'::text, CURRENT_DATE)
            ELSE (date_part('year'::text, CURRENT_DATE) - (1)::double precision)
        END) AS mes_ano,
    meses_para_relatorio.mes
   FROM public.meses_para_relatorio,
    public.ref_mes_atual
  WHERE ((meses_para_relatorio.id >= ref_mes_atual.id_mes_atual) AND (meses_para_relatorio.id <= (ref_mes_atual.id_mes_atual + 11)))
  ORDER BY meses_para_relatorio.id;


ALTER TABLE public.ref_ult_12meses OWNER TO pgadmin;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: pgadmin
--

CREATE TABLE public.usuarios (
    id_usuario uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    nome_usuario character varying(255) NOT NULL,
    email_usuario character varying(255) NOT NULL,
    senha_usuario character varying(255) NOT NULL,
    perfil_usuario character varying(30) DEFAULT 'Solicitante'::character varying NOT NULL,
    acesso_permitido boolean DEFAULT false NOT NULL
);


ALTER TABLE public.usuarios OWNER TO pgadmin;

--
-- Name: view_naturezas_itens; Type: VIEW; Schema: public; Owner: pgadmin
--

CREATE VIEW public.view_naturezas_itens AS
SELECT
    NULL::integer AS id_natureza,
    NULL::character varying(250) AS natureza,
    NULL::integer AS ultimo_registro,
    NULL::bigint AS incidencias;


ALTER TABLE public.view_naturezas_itens OWNER TO pgadmin;

--
-- Name: view_controle_reg_naturezas; Type: VIEW; Schema: public; Owner: pgadmin
--

CREATE VIEW public.view_controle_reg_naturezas AS
 SELECT nat.id_natureza,
    nat.natureza,
    vnat.ultimo_registro
   FROM (public.naturezas nat
     LEFT JOIN public.view_naturezas_itens vnat USING (id_natureza));


ALTER TABLE public.view_controle_reg_naturezas OWNER TO pgadmin;

--
-- Name: view_itens; Type: VIEW; Schema: public; Owner: pgadmin
--

CREATE VIEW public.view_itens AS
 SELECT itens.id_item,
    itens.descricao_item,
    itens.id_natureza,
    naturezas.natureza AS natureza_item,
    itens.marca_item,
    itens.un_medida_item,
    itens.estoque_item
   FROM (public.itens
     JOIN public.naturezas USING (id_natureza))
  ORDER BY itens.descricao_item;


ALTER TABLE public.view_itens OWNER TO pgadmin;

--
-- Name: view_itens_pedido; Type: VIEW; Schema: public; Owner: pgadmin
--

CREATE VIEW public.view_itens_pedido AS
 SELECT view_itens.id_item,
    view_itens.descricao_item,
    view_itens.natureza_item,
    view_itens.marca_item,
    view_itens.un_medida_item,
    view_itens.estoque_item,
    itens_pedido.id_pedido,
    pedidos.id_usuario,
    usuarios.nome_usuario,
    pedidos.data_pedido,
    pedidos.data_atendimento,
    pedidos.finalidade_pedido,
    pedidos.status_pedido,
    itens_pedido.qtd_solicitada,
    itens_pedido.qtd_atendida
   FROM (((public.view_itens
     JOIN public.itens_pedido USING (id_item))
     JOIN public.pedidos USING (id_pedido))
     JOIN public.usuarios USING (id_usuario))
  ORDER BY itens_pedido.id_pedido DESC, pedidos.data_pedido DESC;


ALTER TABLE public.view_itens_pedido OWNER TO pgadmin;

--
-- Name: view_incid_nat_12meses; Type: VIEW; Schema: public; Owner: pgadmin
--

CREATE VIEW public.view_incid_nat_12meses AS
 SELECT incidencia.mes_ano,
    incidencia.natureza,
    incidencia.incidencia
   FROM ( SELECT to_char((vip.data_pedido)::timestamp with time zone, 'mm/YYYY'::text) AS mes_ano,
            vip.natureza_item AS natureza,
            count(vip.natureza_item) AS incidencia
           FROM public.view_itens_pedido vip
          GROUP BY (to_char((vip.data_pedido)::timestamp with time zone, 'mm/YYYY'::text)), vip.natureza_item
          ORDER BY (to_char((vip.data_pedido)::timestamp with time zone, 'mm/YYYY'::text)) DESC) incidencia,
    public.ref_ult_12meses
  WHERE (ref_ult_12meses.mes_ano = incidencia.mes_ano);


ALTER TABLE public.view_incid_nat_12meses OWNER TO pgadmin;

--
-- Name: view_incidência_naturezas_pedidos; Type: VIEW; Schema: public; Owner: pgadmin
--

CREATE VIEW public."view_incidência_naturezas_pedidos" AS
 SELECT view_itens_pedido.natureza_item,
    count(view_itens_pedido.natureza_item) AS incidencia
   FROM public.view_itens_pedido
  GROUP BY view_itens_pedido.natureza_item
  ORDER BY (count(view_itens_pedido.natureza_item)) DESC;


ALTER TABLE public."view_incidência_naturezas_pedidos" OWNER TO pgadmin;

--
-- Name: pedidos id_pedido; Type: DEFAULT; Schema: public; Owner: pgadmin
--

ALTER TABLE ONLY public.pedidos ALTER COLUMN id_pedido SET DEFAULT nextval('public.pedidos_id_pedido_seq'::regclass);


--
-- Data for Name: itens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.itens (id_item, descricao_item, id_natureza, marca_item, un_medida_item, estoque_item) FROM stdin;
\.
COPY public.itens (id_item, descricao_item, id_natureza, marca_item, un_medida_item, estoque_item) FROM '$$PATH$$/3418.dat';

--
-- Data for Name: itens_pedido; Type: TABLE DATA; Schema: public; Owner: pgadmin
--

COPY public.itens_pedido (id_item, id_pedido, qtd_solicitada, qtd_atendida) FROM stdin;
\.
COPY public.itens_pedido (id_item, id_pedido, qtd_solicitada, qtd_atendida) FROM '$$PATH$$/3419.dat';

--
-- Data for Name: meses_para_relatorio; Type: TABLE DATA; Schema: public; Owner: pgadmin
--

COPY public.meses_para_relatorio (id, mes, ref) FROM stdin;
\.
COPY public.meses_para_relatorio (id, mes, ref) FROM '$$PATH$$/3425.dat';

--
-- Data for Name: naturezas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.naturezas (id_natureza, natureza) FROM stdin;
\.
COPY public.naturezas (id_natureza, natureza) FROM '$$PATH$$/3420.dat';

--
-- Data for Name: pedidos; Type: TABLE DATA; Schema: public; Owner: pgadmin
--

COPY public.pedidos (id_pedido, id_usuario, data_pedido, data_atendimento, finalidade_pedido, status_pedido, observacao_atendimento) FROM stdin;
\.
COPY public.pedidos (id_pedido, id_usuario, data_pedido, data_atendimento, finalidade_pedido, status_pedido, observacao_atendimento) FROM '$$PATH$$/3421.dat';

--
-- Data for Name: perfis; Type: TABLE DATA; Schema: public; Owner: pgadmin
--

COPY public.perfis (perfil, permissoes) FROM stdin;
\.
COPY public.perfis (perfil, permissoes) FROM '$$PATH$$/3423.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: pgadmin
--

COPY public.usuarios (id_usuario, nome_usuario, email_usuario, senha_usuario, perfil_usuario, acesso_permitido) FROM stdin;
\.
COPY public.usuarios (id_usuario, nome_usuario, email_usuario, senha_usuario, perfil_usuario, acesso_permitido) FROM '$$PATH$$/3424.dat';

--
-- Name: pedidos_id_pedido_seq; Type: SEQUENCE SET; Schema: public; Owner: pgadmin
--

SELECT pg_catalog.setval('public.pedidos_id_pedido_seq', 14, true);


--
-- Name: itens descticao_marca_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens
    ADD CONSTRAINT descticao_marca_unique UNIQUE (descricao_item, marca_item);


--
-- Name: itens itens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens
    ADD CONSTRAINT itens_pkey PRIMARY KEY (id_item);


--
-- Name: meses_para_relatorio meses_para_relatorio_pkey; Type: CONSTRAINT; Schema: public; Owner: pgadmin
--

ALTER TABLE ONLY public.meses_para_relatorio
    ADD CONSTRAINT meses_para_relatorio_pkey PRIMARY KEY (id);


--
-- Name: naturezas naturezas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.naturezas
    ADD CONSTRAINT naturezas_pkey PRIMARY KEY (id_natureza);


--
-- Name: pedidos pedidos_pkey; Type: CONSTRAINT; Schema: public; Owner: pgadmin
--

ALTER TABLE ONLY public.pedidos
    ADD CONSTRAINT pedidos_pkey PRIMARY KEY (id_pedido);


--
-- Name: perfis perfis_pkey; Type: CONSTRAINT; Schema: public; Owner: pgadmin
--

ALTER TABLE ONLY public.perfis
    ADD CONSTRAINT perfis_pkey PRIMARY KEY (perfil);


--
-- Name: itens_pedido pk_itens_pedido; Type: CONSTRAINT; Schema: public; Owner: pgadmin
--

ALTER TABLE ONLY public.itens_pedido
    ADD CONSTRAINT pk_itens_pedido PRIMARY KEY (id_pedido, id_item);


--
-- Name: perfis unique_perfil; Type: CONSTRAINT; Schema: public; Owner: pgadmin
--

ALTER TABLE ONLY public.perfis
    ADD CONSTRAINT unique_perfil UNIQUE (perfil);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: pgadmin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id_usuario);


--
-- Name: view_naturezas_itens _RETURN; Type: RULE; Schema: public; Owner: pgadmin
--

CREATE OR REPLACE VIEW public.view_naturezas_itens AS
 SELECT naturezas.id_natureza,
    naturezas.natureza,
    max(itens.id_item) AS ultimo_registro,
    count(itens.id_natureza) AS incidencias
   FROM (public.naturezas
     JOIN public.itens USING (id_natureza))
  GROUP BY naturezas.id_natureza
  ORDER BY naturezas.natureza;


--
-- Name: itens_pedido fk_itens; Type: FK CONSTRAINT; Schema: public; Owner: pgadmin
--

ALTER TABLE ONLY public.itens_pedido
    ADD CONSTRAINT fk_itens FOREIGN KEY (id_item) REFERENCES public.itens(id_item);


--
-- Name: itens_pedido fk_pedidos; Type: FK CONSTRAINT; Schema: public; Owner: pgadmin
--

ALTER TABLE ONLY public.itens_pedido
    ADD CONSTRAINT fk_pedidos FOREIGN KEY (id_pedido) REFERENCES public.pedidos(id_pedido);


--
-- Name: usuarios fk_perfil; Type: FK CONSTRAINT; Schema: public; Owner: pgadmin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT fk_perfil FOREIGN KEY (perfil_usuario) REFERENCES public.perfis(perfil) NOT VALID;


--
-- Name: pedidos fk_usuario; Type: FK CONSTRAINT; Schema: public; Owner: pgadmin
--

ALTER TABLE ONLY public.pedidos
    ADD CONSTRAINT fk_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id_usuario);


--
-- Name: itens itens_id_natureza_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens
    ADD CONSTRAINT itens_id_natureza_fkey FOREIGN KEY (id_natureza) REFERENCES public.naturezas(id_natureza);


--
-- PostgreSQL database dump complete
--

